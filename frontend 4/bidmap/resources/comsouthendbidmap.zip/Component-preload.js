//@ui5-bundle com/southend/bidmap/Component-preload.js
jQuery.sap.registerPreloadedModules({
"version":"2.0",
"modules":{
	"com/southend/bidmap/Component.js":function(){sap.ui.define(["sap/ui/core/UIComponent","sap/ui/Device","com/southend/bidmap/model/models"],function(e,t,i){"use strict";return e.extend("com.southend.bidmap.Component",{metadata:{manifest:"json"},init:function(){e.prototype.init.apply(this,arguments);this.getRouter().initialize();this.setModel(i.createDeviceModel(),"device")}})});
},
	"com/southend/bidmap/controller/bidmap.controller.js":function(){sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("com.southend.bidmap.controller.bidmap",{onInit:function(){}})});
},
	"com/southend/bidmap/i18n/i18n.properties":'title=Title\nappTitle=bidmap\nappDescription=App Description\n',
	"com/southend/bidmap/manifest.json":'{"_version":"1.32.0","sap.app":{"id":"com.southend.bidmap","type":"application","i18n":"i18n/i18n.properties","applicationVersion":{"version":"1.0.0"},"title":"{{appTitle}}","description":"{{appDescription}}","resources":"resources.json","ach":"ach"},"sap.ui":{"technology":"UI5","icons":{"icon":"sap-icon://task","favIcon":"","phone":"","phone@2":"","tablet":"","tablet@2":""},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"flexEnabled":false,"rootView":{"viewName":"com.southend.bidmap.view.bidmap","type":"XML","async":true,"id":"bidmap"},"dependencies":{"minUI5Version":"1.97.2","libs":{"sap.ui.core":{},"sap.m":{},"sap.ui.layout":{},"sap.f":{}}},"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"com.southend.bidmap.i18n.i18n"}}},"resources":{"css":[{"uri":"css/style.css"}]},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","async":true,"viewPath":"com.southend.bidmap.view","controlAggregation":"pages","controlId":"app","clearControlAggregation":false},"routes":[{"name":"Routebidmap","pattern":"Routebidmap","target":["Targetbidmap"]}],"targets":{"Targetbidmap":{"viewType":"XML","transition":"slide","clearControlAggregation":false,"viewId":"bidmap","viewName":"bidmap"}}}}}',
	"com/southend/bidmap/model/models.js":function(){sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/Device"],function(e,n){"use strict";return{createDeviceModel:function(){var i=new e(n);i.setDefaultBindingMode("OneWay");return i}}});
},
	"com/southend/bidmap/view/bidmap.view.xml":'<mvc:View\n    controllerName="com.southend.bidmap.controller.bidmap"\n    xmlns:mvc="sap.ui.core.mvc"\n    displayBlock="true"\n    xmlns="sap.m"\n><Shell id="shell"><App id="app"><pages><Page id="page" title="{i18n>title}"><content /></Page></pages></App></Shell></mvc:View>\n'
}});
