sap.ui.define([
	"comsouthend./bidmap/test/unit/controller/bidmap.controller"
], function () {
	"use strict";
});
